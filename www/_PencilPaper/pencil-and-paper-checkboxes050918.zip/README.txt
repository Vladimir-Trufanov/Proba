A Pen created at CodePen.io. You can find this one at https://codepen.io/jkantner/pen/wEeWWG.

 A checkbox concept that simulates filling checkboxes and erasing checks in real life