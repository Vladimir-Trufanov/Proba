A Pen created at CodePen.io. You can find this one at https://codepen.io/kathykato/pen/RgZrZM.

 Hover on the links and it follows the cursor,  highlighting the links as you go!