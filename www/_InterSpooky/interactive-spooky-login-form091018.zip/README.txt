A Pen created at CodePen.io. You can find this one at https://codepen.io/alvaromontoro/pen/bmwmKJ.

 The floating ghost will follow your typing with its eyes, smile when you type a valid email, and cover its eyes when you are writing the password. So there's no peeks, only boos (<-- worst pun ever, sorry).

**EDIT: I found that <a href="https://codepen.io/dsenneff/">Darin Senneff</a> is the actual author of the original form that inspired this one... and I must say, his is so much better than this, <a href="https://codepen.io/dsenneff/full/2c3e5bc86b372d5424b00edaf4990173/">go see it on Codepen!</a>** :)

Inspired by a post I found on [LinkedIn](https://www.linkedin.com/feed/update/activity:6451332556481789952/)) crediting Ramsi Ferkous.